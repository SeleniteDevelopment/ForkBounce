/*
 * Decompiled with CFR 0.152.
 */
package liying.fonts.api;

import liying.fonts.api.FontRenderer;
import liying.fonts.api.FontType;

public interface FontFamily {
    public FontRenderer ofSize(int var1);

    public FontType font();
}

