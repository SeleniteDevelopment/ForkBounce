/*
 * Decompiled with CFR 0.152.
 */
package dev.sakura_starring.util.safe;

public class Safe {
    public static boolean verification = false;
}

