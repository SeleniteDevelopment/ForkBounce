package net.ccbluex.liquidbounce.utils;

public class BlockObject {

    public int x;
    public int height;

    public BlockObject(int x, int height) {
        this.x = x;
        this.height = height;
    }
}
