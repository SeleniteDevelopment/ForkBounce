package net.ccbluex.liquidbounce.utils.messages;

import net.minecraft.util.ChatComponentStyle;
import net.minecraft.util.IChatComponent;

/**
 * @author xDelsy
 */
public class Message extends ChatComponentStyle {

    @Override
    public String getUnformattedTextForChat() {
        return null;
    }

    @Override
    public IChatComponent createCopy() {
        return null;
    }

}
