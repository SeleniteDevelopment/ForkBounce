package net.ccbluex.liquidbounce.ui.client.particle;

import org.lwjgl.util.vector.Vector2f;

public class Particle {
    public Vector2f vector = new Vector2f();

    public void draw(int xAdd) {
    }
}
