package net.ccbluex.liquidbounce.cn.Insane.newdropdown.utils.render;

public enum GuiEvents {

    DRAW,
    CLICK,
    RELEASE

}
