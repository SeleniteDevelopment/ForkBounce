/*
 * LiquidBounce+ Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 */
package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.features.module.*;

@ModuleInfo(name = "ItemPhysics", spacedName = "Item Physics", description = "Apply real life physics into items (when being thrown).", category = ModuleCategory.RENDER)
public class ItemPhysics extends Module
{
}
