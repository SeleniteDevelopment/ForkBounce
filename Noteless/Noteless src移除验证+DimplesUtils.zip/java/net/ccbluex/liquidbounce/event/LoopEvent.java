package net.ccbluex.liquidbounce.event;



/**
 * Created by Admin on 2017/01/30.
 */
public class LoopEvent extends Event {
}