package jdk.internal.dynalink;

import java.lang.invoke.*;
import jdk.internal.dynalink.linker.*;

public interface RelinkableCallSite
{
    void initialize(final MethodHandle p0);
    
    CallSiteDescriptor getDescriptor();
    
    void relink(final GuardedInvocation p0, final MethodHandle p1);
    
    void resetAndRelink(final GuardedInvocation p0, final MethodHandle p1);
}
