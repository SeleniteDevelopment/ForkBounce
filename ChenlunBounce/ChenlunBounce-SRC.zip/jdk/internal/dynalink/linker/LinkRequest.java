package jdk.internal.dynalink.linker;

import jdk.internal.dynalink.*;

public interface LinkRequest
{
    CallSiteDescriptor getCallSiteDescriptor();
    
    Object getCallSiteToken();
    
    Object[] getArguments();
    
    Object getReceiver();
    
    int getLinkCount();
    
    boolean isCallSiteUnstable();
    
    LinkRequest withoutRuntimeContext();
    
    LinkRequest replaceArguments(final CallSiteDescriptor p0, final Object[] p1);
}
