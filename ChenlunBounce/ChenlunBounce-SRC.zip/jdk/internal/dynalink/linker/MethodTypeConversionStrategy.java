package jdk.internal.dynalink.linker;

import java.lang.invoke.*;

public interface MethodTypeConversionStrategy
{
    MethodHandle asType(final MethodHandle p0, final MethodType p1);
}
