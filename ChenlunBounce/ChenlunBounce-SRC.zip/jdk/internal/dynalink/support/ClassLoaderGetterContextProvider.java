package jdk.internal.dynalink.support;

import java.security.*;

public class ClassLoaderGetterContextProvider
{
    public static final AccessControlContext GET_CLASS_LOADER_CONTEXT;
    
    static {
        final Permissions perms = new Permissions();
        perms.add(new RuntimePermission("getClassLoader"));
        GET_CLASS_LOADER_CONTEXT = new AccessControlContext(new ProtectionDomain[] { new ProtectionDomain(null, perms) });
    }
}
