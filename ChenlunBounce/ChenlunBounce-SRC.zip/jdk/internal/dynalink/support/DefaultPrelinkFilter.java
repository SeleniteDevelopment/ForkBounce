package jdk.internal.dynalink.support;

import jdk.internal.dynalink.*;
import jdk.internal.dynalink.linker.*;

public class DefaultPrelinkFilter implements GuardedInvocationFilter
{
    @Override
    public GuardedInvocation filter(final GuardedInvocation inv, final LinkRequest request, final LinkerServices linkerServices) {
        return inv.asType(linkerServices, request.getCallSiteDescriptor().getMethodType());
    }
}
