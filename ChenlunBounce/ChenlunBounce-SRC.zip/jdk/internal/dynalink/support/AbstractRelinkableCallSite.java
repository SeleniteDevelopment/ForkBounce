package jdk.internal.dynalink.support;

import jdk.internal.dynalink.*;
import java.lang.invoke.*;

public abstract class AbstractRelinkableCallSite extends MutableCallSite implements RelinkableCallSite
{
    private final CallSiteDescriptor descriptor;
    
    protected AbstractRelinkableCallSite(final CallSiteDescriptor descriptor) {
        super(descriptor.getMethodType());
        this.descriptor = descriptor;
    }
    
    @Override
    public CallSiteDescriptor getDescriptor() {
        return this.descriptor;
    }
    
    @Override
    public void initialize(final MethodHandle relinkAndInvoke) {
        this.setTarget(relinkAndInvoke);
    }
}
