package jdk.internal.dynalink.support;

import jdk.internal.dynalink.*;
import java.lang.invoke.*;
import java.lang.ref.*;
import java.util.*;

public class CallSiteDescriptorFactory
{
    private static final WeakHashMap<CallSiteDescriptor, Reference<CallSiteDescriptor>> publicDescs;
    
    public static CallSiteDescriptor create(final MethodHandles.Lookup lookup, final String name, final MethodType methodType) {
        Objects.requireNonNull(name);
        Objects.requireNonNull(methodType);
        Objects.requireNonNull(lookup);
        final String[] tokenizedName = tokenizeName(name);
        if (isPublicLookup(lookup)) {
            return getCanonicalPublicDescriptor(createPublicCallSiteDescriptor(tokenizedName, methodType));
        }
        return new LookupCallSiteDescriptor(tokenizedName, methodType, lookup);
    }
    
    static CallSiteDescriptor getCanonicalPublicDescriptor(final CallSiteDescriptor desc) {
        synchronized (CallSiteDescriptorFactory.publicDescs) {
            final Reference<CallSiteDescriptor> ref = CallSiteDescriptorFactory.publicDescs.get(desc);
            if (ref != null) {
                final CallSiteDescriptor canonical = ref.get();
                if (canonical != null) {
                    return canonical;
                }
            }
            CallSiteDescriptorFactory.publicDescs.put(desc, createReference(desc));
        }
        return desc;
    }
    
    protected static Reference<CallSiteDescriptor> createReference(final CallSiteDescriptor desc) {
        return new WeakReference<CallSiteDescriptor>(desc);
    }
    
    private static CallSiteDescriptor createPublicCallSiteDescriptor(final String[] tokenizedName, final MethodType methodType) {
        final int l = tokenizedName.length;
        if (l > 0 && tokenizedName[0] == "dyn") {
            if (l == 2) {
                return new UnnamedDynCallSiteDescriptor(tokenizedName[1], methodType);
            }
            if (l == 3) {
                return new NamedDynCallSiteDescriptor(tokenizedName[1], tokenizedName[2], methodType);
            }
        }
        return new DefaultCallSiteDescriptor(tokenizedName, methodType);
    }
    
    private static boolean isPublicLookup(final MethodHandles.Lookup lookup) {
        return lookup == MethodHandles.publicLookup();
    }
    
    public static String[] tokenizeName(final String name) {
        final StringTokenizer tok = new StringTokenizer(name, ":");
        final String[] tokens = new String[tok.countTokens()];
        for (int i = 0; i < tokens.length; ++i) {
            String token = tok.nextToken();
            if (i > 1) {
                token = NameCodec.decode(token);
            }
            tokens[i] = token.intern();
        }
        return tokens;
    }
    
    public static List<String> tokenizeOperators(final CallSiteDescriptor desc) {
        final String ops = desc.getNameToken(1);
        final StringTokenizer tok = new StringTokenizer(ops, "|");
        final int count = tok.countTokens();
        if (count == 1) {
            return Collections.singletonList(ops);
        }
        final String[] tokens = new String[count];
        for (int i = 0; i < count; ++i) {
            tokens[i] = tok.nextToken();
        }
        return Arrays.asList(tokens);
    }
    
    public static CallSiteDescriptor dropParameterTypes(final CallSiteDescriptor desc, final int start, final int end) {
        return desc.changeMethodType(desc.getMethodType().dropParameterTypes(start, end));
    }
    
    public static CallSiteDescriptor changeParameterType(final CallSiteDescriptor desc, final int num, final Class<?> nptype) {
        return desc.changeMethodType(desc.getMethodType().changeParameterType(num, nptype));
    }
    
    public static CallSiteDescriptor changeReturnType(final CallSiteDescriptor desc, final Class<?> nrtype) {
        return desc.changeMethodType(desc.getMethodType().changeReturnType(nrtype));
    }
    
    public static CallSiteDescriptor insertParameterTypes(final CallSiteDescriptor desc, final int num, final Class<?>... ptypesToInsert) {
        return desc.changeMethodType(desc.getMethodType().insertParameterTypes(num, ptypesToInsert));
    }
    
    public static CallSiteDescriptor insertParameterTypes(final CallSiteDescriptor desc, final int num, final List<Class<?>> ptypesToInsert) {
        return desc.changeMethodType(desc.getMethodType().insertParameterTypes(num, ptypesToInsert));
    }
    
    static {
        publicDescs = new WeakHashMap<CallSiteDescriptor, Reference<CallSiteDescriptor>>();
    }
}
