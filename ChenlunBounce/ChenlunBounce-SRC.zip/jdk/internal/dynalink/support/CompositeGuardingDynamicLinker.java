package jdk.internal.dynalink.support;

import java.io.*;
import java.util.*;
import jdk.internal.dynalink.linker.*;

public class CompositeGuardingDynamicLinker implements GuardingDynamicLinker, Serializable
{
    private static final long serialVersionUID = 1L;
    private final GuardingDynamicLinker[] linkers;
    
    public CompositeGuardingDynamicLinker(final Iterable<? extends GuardingDynamicLinker> linkers) {
        final List<GuardingDynamicLinker> l = new LinkedList<GuardingDynamicLinker>();
        for (final GuardingDynamicLinker linker : linkers) {
            l.add(linker);
        }
        this.linkers = l.toArray(new GuardingDynamicLinker[l.size()]);
    }
    
    @Override
    public GuardedInvocation getGuardedInvocation(final LinkRequest linkRequest, final LinkerServices linkerServices) throws Exception {
        for (final GuardingDynamicLinker linker : this.linkers) {
            final GuardedInvocation invocation = linker.getGuardedInvocation(linkRequest, linkerServices);
            if (invocation != null) {
                return invocation;
            }
        }
        return null;
    }
}
