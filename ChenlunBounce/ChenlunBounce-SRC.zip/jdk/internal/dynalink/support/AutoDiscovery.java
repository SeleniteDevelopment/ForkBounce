package jdk.internal.dynalink.support;

import jdk.internal.dynalink.linker.*;
import java.util.*;

public class AutoDiscovery
{
    public static List<GuardingDynamicLinker> loadLinkers() {
        return getLinkers((ServiceLoader<GuardingDynamicLinker>)ServiceLoader.load((Class<T>)GuardingDynamicLinker.class));
    }
    
    public static List<GuardingDynamicLinker> loadLinkers(final ClassLoader cl) {
        return getLinkers((ServiceLoader<GuardingDynamicLinker>)ServiceLoader.load((Class<T>)GuardingDynamicLinker.class, cl));
    }
    
    private static <T> List<T> getLinkers(final ServiceLoader<T> loader) {
        final List<T> list = new LinkedList<T>();
        for (final T linker : loader) {
            list.add(linker);
        }
        return list;
    }
}
