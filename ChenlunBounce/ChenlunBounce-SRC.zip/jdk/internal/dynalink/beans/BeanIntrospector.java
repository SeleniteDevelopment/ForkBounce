package jdk.internal.dynalink.beans;

import java.lang.invoke.*;
import java.util.*;

class BeanIntrospector extends FacetIntrospector
{
    BeanIntrospector(final Class<?> clazz) {
        super(clazz, true);
    }
    
    @Override
    Map<String, MethodHandle> getInnerClassGetters() {
        return Collections.emptyMap();
    }
    
    @Override
    MethodHandle editMethodHandle(final MethodHandle mh) {
        return mh;
    }
}
