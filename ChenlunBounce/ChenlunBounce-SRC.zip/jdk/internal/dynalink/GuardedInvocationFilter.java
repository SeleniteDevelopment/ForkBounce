package jdk.internal.dynalink;

import jdk.internal.dynalink.linker.*;

public interface GuardedInvocationFilter
{
    GuardedInvocation filter(final GuardedInvocation p0, final LinkRequest p1, final LinkerServices p2);
}
