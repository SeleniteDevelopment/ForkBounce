package jdk.internal.dynalink;

import java.lang.invoke.*;
import jdk.internal.dynalink.support.*;

public class DefaultBootstrapper
{
    private static final DynamicLinker dynamicLinker;
    
    public static CallSite bootstrap(final MethodHandles.Lookup caller, final String name, final MethodType type) {
        return bootstrapInternal(caller, name, type);
    }
    
    public static CallSite publicBootstrap(final MethodHandles.Lookup caller, final String name, final MethodType type) {
        return bootstrapInternal(MethodHandles.publicLookup(), name, type);
    }
    
    private static CallSite bootstrapInternal(final MethodHandles.Lookup caller, final String name, final MethodType type) {
        return DefaultBootstrapper.dynamicLinker.link(new MonomorphicCallSite(CallSiteDescriptorFactory.create(caller, name, type)));
    }
    
    static {
        dynamicLinker = new DynamicLinkerFactory().createLinker();
    }
}
