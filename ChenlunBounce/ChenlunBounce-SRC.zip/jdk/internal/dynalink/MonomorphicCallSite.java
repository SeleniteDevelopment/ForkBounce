package jdk.internal.dynalink;

import jdk.internal.dynalink.support.*;
import jdk.internal.dynalink.linker.*;
import java.lang.invoke.*;

public class MonomorphicCallSite extends AbstractRelinkableCallSite
{
    public MonomorphicCallSite(final CallSiteDescriptor descriptor) {
        super(descriptor);
    }
    
    @Override
    public void relink(final GuardedInvocation guardedInvocation, final MethodHandle relink) {
        this.setTarget(guardedInvocation.compose(relink));
    }
    
    @Override
    public void resetAndRelink(final GuardedInvocation guardedInvocation, final MethodHandle relink) {
        this.relink(guardedInvocation, relink);
    }
}
