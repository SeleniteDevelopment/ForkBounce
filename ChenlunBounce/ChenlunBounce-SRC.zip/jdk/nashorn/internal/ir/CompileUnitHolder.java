package jdk.nashorn.internal.ir;

import jdk.nashorn.internal.codegen.*;

public interface CompileUnitHolder
{
    CompileUnit getCompileUnit();
}
