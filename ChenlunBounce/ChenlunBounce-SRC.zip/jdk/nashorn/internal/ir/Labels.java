package jdk.nashorn.internal.ir;

import java.util.*;
import jdk.nashorn.internal.codegen.*;

public interface Labels
{
    List<Label> getLabels();
}
