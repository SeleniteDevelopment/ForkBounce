package jdk.nashorn.internal.ir;

import jdk.nashorn.internal.codegen.*;

public interface BreakableNode extends LexicalContextNode, JoinPredecessor, Labels
{
    Node ensureUniqueLabels(final LexicalContext p0);
    
    boolean isBreakableWithoutLabel();
    
    Label getBreakLabel();
}
