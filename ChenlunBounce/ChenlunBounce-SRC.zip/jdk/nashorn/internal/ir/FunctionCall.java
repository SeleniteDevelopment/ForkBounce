package jdk.nashorn.internal.ir;

public interface FunctionCall
{
    boolean isFunction();
}
