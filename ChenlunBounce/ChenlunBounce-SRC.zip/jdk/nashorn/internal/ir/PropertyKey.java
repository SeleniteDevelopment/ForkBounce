package jdk.nashorn.internal.ir;

public interface PropertyKey
{
    String getPropertyName();
}
