package jdk.nashorn.internal.ir.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
public @interface Reference {
}
