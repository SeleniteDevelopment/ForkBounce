package jdk.nashorn.internal.ir.annotations;

import java.lang.annotation.*;

public @interface Immutable {
}
