package jdk.nashorn.internal.ir;

import jdk.nashorn.internal.codegen.types.*;
import jdk.nashorn.internal.ir.visitor.*;
import jdk.nashorn.internal.runtime.*;
import java.lang.invoke.*;
import jdk.nashorn.internal.codegen.*;
import jdk.internal.org.objectweb.asm.*;

public final class GetSplitState extends Expression
{
    private static final long serialVersionUID = 1L;
    public static final GetSplitState INSTANCE;
    
    private GetSplitState() {
        super(0L, 0);
    }
    
    @Override
    public Type getType() {
        return Type.INT;
    }
    
    @Override
    public Node accept(final NodeVisitor<? extends LexicalContext> visitor) {
        return visitor.enterGetSplitState(this) ? visitor.leaveGetSplitState(this) : this;
    }
    
    @Override
    public void toString(final StringBuilder sb, final boolean printType) {
        if (printType) {
            sb.append("{I}");
        }
        sb.append(CompilerConstants.SCOPE.symbolName()).append('.').append(Scope.GET_SPLIT_STATE.name()).append("()");
    }
    
    private Object readResolve() {
        return GetSplitState.INSTANCE;
    }
    
    static {
        INSTANCE = new GetSplitState();
    }
}
