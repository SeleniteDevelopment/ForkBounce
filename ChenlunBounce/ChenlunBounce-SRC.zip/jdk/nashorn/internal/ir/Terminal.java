package jdk.nashorn.internal.ir;

public interface Terminal
{
    boolean isTerminal();
}
