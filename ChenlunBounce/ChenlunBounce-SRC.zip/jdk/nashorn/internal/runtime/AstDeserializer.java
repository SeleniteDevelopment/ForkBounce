package jdk.nashorn.internal.runtime;

import jdk.nashorn.internal.ir.*;
import java.util.zip.*;
import java.io.*;

final class AstDeserializer
{
    static FunctionNode deserialize(final byte[] serializedAst) {
        try {
            return (FunctionNode)new ObjectInputStream(new InflaterInputStream(new ByteArrayInputStream(serializedAst))).readObject();
        }
        catch (ClassNotFoundException | IOException ex2) {
            final Exception ex;
            final Exception e = ex;
            throw new AssertionError("Unexpected exception deserializing function", e);
        }
    }
}
