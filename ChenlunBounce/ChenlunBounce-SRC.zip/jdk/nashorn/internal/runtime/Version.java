package jdk.nashorn.internal.runtime;

import java.util.*;

public final class Version
{
    private static final String VERSION_RB_NAME = "jdk.nashorn.internal.runtime.resources.version";
    private static ResourceBundle versionRB;
    
    public static String version() {
        return version("release");
    }
    
    public static String fullVersion() {
        return version("full");
    }
    
    private static String version(final String key) {
        if (Version.versionRB == null) {
            try {
                Version.versionRB = ResourceBundle.getBundle("jdk.nashorn.internal.runtime.resources.version");
            }
            catch (MissingResourceException e) {
                return "version not available";
            }
        }
        try {
            return Version.versionRB.getString(key);
        }
        catch (MissingResourceException e) {
            return "version not available";
        }
    }
}
