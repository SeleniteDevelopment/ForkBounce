package jdk.nashorn.internal.runtime.regexp.joni.ast;

public final class AnyCharNode extends Node
{
    @Override
    public int getType() {
        return 3;
    }
    
    @Override
    public String getName() {
        return "Any Char";
    }
    
    public String toString(final int level) {
        final String value = "";
        return "";
    }
}
