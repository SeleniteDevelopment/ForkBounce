package jdk.nashorn.internal.runtime.arrays;

public interface AnyElements
{
    int getElementWeight();
}
