package jdk.nashorn.internal.runtime.arrays;

public interface NumericElements extends AnyElements
{
}
