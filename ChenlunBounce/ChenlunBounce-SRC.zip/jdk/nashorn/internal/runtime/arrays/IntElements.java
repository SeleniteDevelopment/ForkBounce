package jdk.nashorn.internal.runtime.arrays;

public interface IntElements extends IntOrLongElements
{
}
