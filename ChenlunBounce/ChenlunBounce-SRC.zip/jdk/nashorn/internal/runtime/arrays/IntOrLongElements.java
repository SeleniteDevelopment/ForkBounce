package jdk.nashorn.internal.runtime.arrays;

public interface IntOrLongElements extends NumericElements
{
}
