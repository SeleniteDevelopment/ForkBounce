package jdk.nashorn.internal.runtime.arrays;

import jdk.nashorn.internal.runtime.*;
import jdk.nashorn.api.scripting.*;
import java.util.*;

public abstract class ArrayLikeIterator<T> implements Iterator<T>
{
    protected long index;
    protected final boolean includeUndefined;
    
    ArrayLikeIterator(final boolean includeUndefined) {
        this.includeUndefined = includeUndefined;
        this.index = 0L;
    }
    
    public boolean isReverse() {
        return false;
    }
    
    protected long bumpIndex() {
        return this.index++;
    }
    
    public long nextIndex() {
        return this.index;
    }
    
    @Override
    public void remove() {
        throw new UnsupportedOperationException("remove");
    }
    
    public abstract long getLength();
    
    public static ArrayLikeIterator<Object> arrayLikeIterator(final Object object) {
        return arrayLikeIterator(object, false);
    }
    
    public static ArrayLikeIterator<Object> reverseArrayLikeIterator(final Object object) {
        return reverseArrayLikeIterator(object, false);
    }
    
    public static ArrayLikeIterator<Object> arrayLikeIterator(final Object object, final boolean includeUndefined) {
        if (ScriptObject.isArray(object)) {
            return new ScriptArrayIterator((ScriptObject)object, includeUndefined);
        }
        final Object obj = JSType.toScriptObject(object);
        if (obj instanceof ScriptObject) {
            return new ScriptObjectIterator((ScriptObject)obj, includeUndefined);
        }
        if (obj instanceof JSObject) {
            return new JSObjectIterator((JSObject)obj, includeUndefined);
        }
        if (obj instanceof List) {
            return new JavaListIterator((List<?>)obj, includeUndefined);
        }
        if (obj != null && obj.getClass().isArray()) {
            return new JavaArrayIterator(obj, includeUndefined);
        }
        return new EmptyArrayLikeIterator();
    }
    
    public static ArrayLikeIterator<Object> reverseArrayLikeIterator(final Object object, final boolean includeUndefined) {
        if (ScriptObject.isArray(object)) {
            return new ReverseScriptArrayIterator((ScriptObject)object, includeUndefined);
        }
        final Object obj = JSType.toScriptObject(object);
        if (obj instanceof ScriptObject) {
            return new ReverseScriptObjectIterator((ScriptObject)obj, includeUndefined);
        }
        if (obj instanceof JSObject) {
            return new ReverseJSObjectIterator((JSObject)obj, includeUndefined);
        }
        if (obj instanceof List) {
            return new ReverseJavaListIterator((List<?>)obj, includeUndefined);
        }
        if (obj != null && obj.getClass().isArray()) {
            return new ReverseJavaArrayIterator(obj, includeUndefined);
        }
        return new EmptyArrayLikeIterator();
    }
}
