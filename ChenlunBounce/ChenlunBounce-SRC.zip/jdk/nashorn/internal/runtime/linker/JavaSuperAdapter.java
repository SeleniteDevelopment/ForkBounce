package jdk.nashorn.internal.runtime.linker;

import java.util.*;

class JavaSuperAdapter
{
    private final Object adapter;
    
    JavaSuperAdapter(final Object adapter) {
        this.adapter = Objects.requireNonNull(adapter);
    }
    
    public Object getAdapter() {
        return this.adapter;
    }
}
