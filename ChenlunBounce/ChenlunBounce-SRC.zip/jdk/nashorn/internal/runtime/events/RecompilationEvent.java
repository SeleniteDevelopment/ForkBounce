package jdk.nashorn.internal.runtime.events;

import java.util.logging.*;
import jdk.nashorn.internal.runtime.*;
import jdk.nashorn.internal.runtime.logging.*;

public final class RecompilationEvent extends RuntimeEvent<RewriteException>
{
    private final Object returnValue;
    
    public RecompilationEvent(final Level level, final RewriteException rewriteException, final Object returnValue) {
        super(level, rewriteException);
        assert Context.getContext().getLogger(RecompilableScriptFunctionData.class).isEnabled() : "Unit test/instrumentation purpose only: RecompilationEvent instances should not be created without '--log=recompile', or we will leak memory in the general case";
        this.returnValue = returnValue;
    }
    
    public Object getReturnValue() {
        return this.returnValue;
    }
}
