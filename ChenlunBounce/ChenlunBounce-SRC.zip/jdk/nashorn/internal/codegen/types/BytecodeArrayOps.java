package jdk.nashorn.internal.codegen.types;

import jdk.internal.org.objectweb.asm.*;

interface BytecodeArrayOps
{
    Type aload(final MethodVisitor p0);
    
    void astore(final MethodVisitor p0);
    
    Type arraylength(final MethodVisitor p0);
    
    Type newarray(final MethodVisitor p0);
    
    Type newarray(final MethodVisitor p0, final int p1);
}
