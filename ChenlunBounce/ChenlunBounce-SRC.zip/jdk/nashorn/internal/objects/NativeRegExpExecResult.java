package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.regexp.*;
import jdk.nashorn.internal.runtime.arrays.*;
import jdk.nashorn.internal.runtime.*;

public final class NativeRegExpExecResult extends ScriptObject
{
    public Object index;
    public Object input;
    private static PropertyMap $nasgenmap$;
    
    NativeRegExpExecResult(final RegExpResult result, final Global global) {
        super(global.getArrayPrototype(), NativeRegExpExecResult.$nasgenmap$);
        this.setIsArray();
        this.setArray(ArrayData.allocate(result.getGroups().clone()));
        this.index = result.getIndex();
        this.input = result.getInput();
    }
    
    @Override
    public String getClassName() {
        return "Array";
    }
    
    public static Object length(final Object self) {
        if (self instanceof ScriptObject) {
            return JSType.toUint32(((ScriptObject)self).getArray().length());
        }
        return 0;
    }
    
    public static void length(final Object self, final Object length) {
        if (self instanceof ScriptObject) {
            ((ScriptObject)self).setLength(NativeArray.validLength(length));
        }
    }
    
    static {
        $clinit$();
    }
    
    public static void $clinit$() {
        // 
        // This method could not be decompiled.
        // 
        // Could not show original bytecode, likely due to the same error.
        // 
        // The error that occurred was:
        // 
        // com.strobel.assembler.metadata.MethodBodyParseException: An error occurred while parsing the bytecode of method 'jdk/nashorn/internal/objects/NativeRegExpExecResult.$clinit$:()V'.
        //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:65)
        //     at com.strobel.assembler.metadata.MethodDefinition.tryLoadBody(MethodDefinition.java:729)
        //     at com.strobel.assembler.metadata.MethodDefinition.getBody(MethodDefinition.java:83)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:202)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:757)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:655)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:532)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:499)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:141)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:130)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:105)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at us.deathmarine.luyten.FileSaver.doSaveJarDecompiled(FileSaver.java:326)
        //     at us.deathmarine.luyten.FileSaver.access$300(FileSaver.java:39)
        //     at us.deathmarine.luyten.FileSaver$4.run(FileSaver.java:106)
        //     at java.lang.Thread.run(Unknown Source)
        // Caused by: java.lang.ClassCastException: com.strobel.assembler.ir.ConstantPool$MethodHandleEntry cannot be cast to com.strobel.assembler.ir.ConstantPool$ConstantEntry
        //     at com.strobel.assembler.ir.ConstantPool.lookupConstant(ConstantPool.java:120)
        //     at com.strobel.assembler.metadata.ClassFileReader$Scope.lookupConstant(ClassFileReader.java:1318)
        //     at com.strobel.assembler.metadata.MethodReader.readBodyCore(MethodReader.java:286)
        //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:62)
        //     ... 17 more
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public Object G$index() {
        return this.index;
    }
    
    public void S$index(final Object index) {
        this.index = index;
    }
    
    public Object G$input() {
        return this.input;
    }
    
    public void S$input(final Object input) {
        this.input = input;
    }
}
