package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.*;

public final class NativeReferenceError extends ScriptObject
{
    public Object instMessage;
    public Object nashornException;
    private static PropertyMap $nasgenmap$;
    
    private NativeReferenceError(final Object msg, final ScriptObject proto, final PropertyMap map) {
        super(proto, map);
        if (msg != ScriptRuntime.UNDEFINED) {
            this.instMessage = JSType.toString(msg);
        }
        else {
            this.delete("message", false);
        }
        NativeError.initException(this);
    }
    
    NativeReferenceError(final Object msg, final Global global) {
        this(msg, global.getReferenceErrorPrototype(), NativeReferenceError.$nasgenmap$);
    }
    
    private NativeReferenceError(final Object msg) {
        this(msg, Global.instance());
    }
    
    @Override
    public String getClassName() {
        return "Error";
    }
    
    public static NativeReferenceError constructor(final boolean newObj, final Object self, final Object msg) {
        return new NativeReferenceError(msg);
    }
    
    static {
        $clinit$();
    }
    
    public static void $clinit$() {
        // 
        // This method could not be decompiled.
        // 
        // Could not show original bytecode, likely due to the same error.
        // 
        // The error that occurred was:
        // 
        // com.strobel.assembler.metadata.MethodBodyParseException: An error occurred while parsing the bytecode of method 'jdk/nashorn/internal/objects/NativeReferenceError.$clinit$:()V'.
        //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:65)
        //     at com.strobel.assembler.metadata.MethodDefinition.tryLoadBody(MethodDefinition.java:729)
        //     at com.strobel.assembler.metadata.MethodDefinition.getBody(MethodDefinition.java:83)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:202)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:757)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:655)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:532)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:499)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:141)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:130)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:105)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at us.deathmarine.luyten.FileSaver.doSaveJarDecompiled(FileSaver.java:326)
        //     at us.deathmarine.luyten.FileSaver.access$300(FileSaver.java:39)
        //     at us.deathmarine.luyten.FileSaver$4.run(FileSaver.java:106)
        //     at java.lang.Thread.run(Unknown Source)
        // Caused by: java.lang.ClassCastException: com.strobel.assembler.ir.ConstantPool$MethodHandleEntry cannot be cast to com.strobel.assembler.ir.ConstantPool$ConstantEntry
        //     at com.strobel.assembler.ir.ConstantPool.lookupConstant(ConstantPool.java:120)
        //     at com.strobel.assembler.metadata.ClassFileReader$Scope.lookupConstant(ClassFileReader.java:1318)
        //     at com.strobel.assembler.metadata.MethodReader.readBodyCore(MethodReader.java:286)
        //     at com.strobel.assembler.metadata.MethodReader.readBody(MethodReader.java:62)
        //     ... 17 more
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public Object G$instMessage() {
        return this.instMessage;
    }
    
    public void S$instMessage(final Object instMessage) {
        this.instMessage = instMessage;
    }
    
    public Object G$nashornException() {
        return this.nashornException;
    }
    
    public void S$nashornException(final Object nashornException) {
        this.nashornException = nashornException;
    }
}
