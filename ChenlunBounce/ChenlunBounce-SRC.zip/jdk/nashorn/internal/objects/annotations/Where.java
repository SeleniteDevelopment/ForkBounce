package jdk.nashorn.internal.objects.annotations;

public enum Where
{
    CONSTRUCTOR, 
    PROTOTYPE, 
    INSTANCE;
}
