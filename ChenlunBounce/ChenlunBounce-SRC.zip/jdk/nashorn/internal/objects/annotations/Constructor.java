package jdk.nashorn.internal.objects.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface Constructor {
    String name() default "";
    
    int arity() default -2;
}
