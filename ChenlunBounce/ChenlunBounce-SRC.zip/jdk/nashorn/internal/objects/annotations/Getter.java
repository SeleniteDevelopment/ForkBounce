package jdk.nashorn.internal.objects.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface Getter {
    String name() default "";
    
    int attributes() default 0;
    
    Where where() default Where.INSTANCE;
}
