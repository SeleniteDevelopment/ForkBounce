package jdk.nashorn.api.scripting;

import jdk.*;
import java.net.*;
import java.nio.charset.*;
import java.util.*;
import jdk.nashorn.internal.runtime.*;
import java.io.*;

@Exported
public final class URLReader extends Reader
{
    private final URL url;
    private final Charset cs;
    private Reader reader;
    
    public URLReader(final URL url) {
        this(url, (Charset)null);
    }
    
    public URLReader(final URL url, final String charsetName) {
        this(url, Charset.forName(charsetName));
    }
    
    public URLReader(final URL url, final Charset cs) {
        this.url = Objects.requireNonNull(url);
        this.cs = cs;
    }
    
    @Override
    public int read(final char[] cbuf, final int off, final int len) throws IOException {
        return this.getReader().read(cbuf, off, len);
    }
    
    @Override
    public void close() throws IOException {
        this.getReader().close();
    }
    
    public URL getURL() {
        return this.url;
    }
    
    public Charset getCharset() {
        return this.cs;
    }
    
    private Reader getReader() throws IOException {
        synchronized (this.lock) {
            if (this.reader == null) {
                this.reader = new CharArrayReader(Source.readFully(this.url, this.cs));
            }
        }
        return this.reader;
    }
}
