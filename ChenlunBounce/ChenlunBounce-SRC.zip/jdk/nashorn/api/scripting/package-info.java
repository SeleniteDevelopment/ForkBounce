package jdk.nashorn.api.scripting;

import jdk.*;

@Exported
interface package-info
{
}
