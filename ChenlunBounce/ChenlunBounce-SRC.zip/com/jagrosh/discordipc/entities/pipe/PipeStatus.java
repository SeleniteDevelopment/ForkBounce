package com.jagrosh.discordipc.entities.pipe;

public enum PipeStatus
{
    UNINITIALIZED, 
    CONNECTING, 
    CONNECTED, 
    CLOSED, 
    DISCONNECTED;
}
