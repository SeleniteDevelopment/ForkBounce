package com.jagrosh.discordipc.exceptions;

public class NoDiscordClientException extends Exception
{
}
